package edu.cofc.csci230;

/**
 * Utilities class that will sort in ascending and descending order the elements of a list.
 *
 * The sorting algorithms supported in this class are: 1. selection sort 2. bubble sort 3. insertion
 * sort
 *
 * @author CSCI 230: Data Structures and Algorithms Fall 2018
 */
public class Utils {
    public static boolean ascending = true;

    /**
     *
     */
    private Utils() {

    } // end private constructor

  /**
   *
   * @param list
   */
    public static <AnyType extends Comparable> void selectionSort(List<AnyType> list)
        throws IndexOutOfBoundsException {

      /*
       * DONE:
       *
       * Implement selection sort algorithm as
       * described in class. The pseudo-code for
       * this algorithm can also be found in the
       * content section on OAKS and at the end
       * of the homework assignment.
       *
       * Must sort in:
       * -----------------------------------------
       * 1. ascending order (first element
       * in list is smallest value, last element in
       * list is largest value).
       *
       * 2. descending order (first element
       * in list is largest value, last element in
       * list is smallest value).
       *
       */
        int min_max;

        for (int start = 0; start < list.size() - 1; start++) {
          min_max = start;

          for (int end = start + 1; end < list.size(); end++) {
            if (ascending) {
              if (list.get(end).compareTo(list.get(min_max)) < 0) {
                min_max = end;
              }
            } else {
              if (list.get(end).compareTo(list.get(min_max)) > 0) {
                min_max = end;
              }
            }
          }
          list.swap(start, min_max);
        }
        System.out.printf("Ascending order [%b]\n", ascending);
      } // end selectionSort() method

      /**
       *
       * @param list
       */
      public static <AnyType extends Comparable> void bubbleSort(List<AnyType> list)
          throws IndexOutOfBoundsException {

        /*
         * DONE:
         *
         * Implement bubble sort algorithm as
         * described in class. The pseudo-code for
         * this algorithm can also be found in the
         * content section on OAKS and at the end
         * of the homework assignment.
         *
         *
         * Must sort in:
         * -----------------------------------------
         * 1. ascending order (first element
         * in list is smallest value, last element in
         * list is largest value).
         *
         * 2. descending order (first element
         * in list is largest value, last element in
         * list is smallest value).
         *
         */

        for (int start = 0; start < list.size() - 1; start++) {
          for (int end = 0; end < list.size() - 1 - start; end++) {
            if (ascending) {
              if (list.get(end + 1).compareTo(list.get(end)) < 0) {
                list.swap(end, end + 1);
              }
            } else {
              if (list.get(end + 1).compareTo(list.get(end)) > 0) {
                list.swap(end, end + 1);
              }
            }
          }
        }
        System.out.printf("Ascending order [%b]\n", ascending);
      } // end bubbleSort() method

      /**
       *
       * @param list
       */
      public static <AnyType extends Comparable> void insertionSort(List<AnyType> list)
          throws IndexOutOfBoundsException {

        /*
         * DONE:
         *
         * Implement insertion sort algorithm as
         * described in class. The pseudo-code for
         * this algorithm can also be found in the
         * content section on OAKS and at the end
         * of the homework assignment.
         *
         *
         * Must sort in:
         * -----------------------------------------
         * 1. ascending order (first element
         * in list is smallest value, last element in
         * list is largest value).
         *
         * 2. descending order (first element
         * in list is largest value, last element in
         * list is smallest value).
         *
         */

        for (int start = 1; start < list.size(); start++) {
          //Compares element at start to each element prior to start
          for (int end = start; end > 0; end--) {
            if (ascending) {
              if (list.get(end).compareTo(list.get(end - 1)) < 0) {
                list.swap(end, end - 1);
              }
            } else {
              if (list.get(end).compareTo(list.get(end - 1)) > 0) {
                list.swap(end, end - 1);
              }
            }
          }
        }
        System.out.printf("Ascending order [%b]\n", ascending);
      } // end insertionSort() method
  } // end Utils class definition
