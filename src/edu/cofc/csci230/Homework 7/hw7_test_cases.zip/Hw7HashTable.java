package tests;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.security.Permission;
import java.security.KeyStore.LoadStoreParameter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.print.attribute.standard.OrientationRequested;
import javax.swing.SpringLayout.Constraints;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import edu.cofc.csci230.HashSimulator;
import edu.cofc.csci230.HashTableKeyException;

class Hw7HashTable {

	private static PrintStream originalOut = System.out;
	private ByteArrayOutputStream out;
	private ByteArrayOutputStream err;
	double pointsLost;
	private final static double TOTAL_POINTS = 160;
	private final static double NUMBER_OF_TEST_CASES = 4;
	private final static double POINTS_PER_TEST = TOTAL_POINTS/NUMBER_OF_TEST_CASES;
	static final String UNEXPECTED_EXCEPTION = "Unexpected exception.";
	
	private static double grade = TOTAL_POINTS;
	
	@AfterAll
	static void printGrade() {
		System.setOut(originalOut);
		System.out.println(String.format("You scored a %.2f out of %.2f", grade, TOTAL_POINTS));
	}

	
	@BeforeEach
	void setUp() throws Exception {
		pointsLost = 0;
		System.setSecurityManager(new NoExitSecurityManager());
		out = new ByteArrayOutputStream();
		err = new ByteArrayOutputStream();
		System.setOut(new PrintStream(out));
		System.setErr(new PrintStream(err));
	}

	@AfterEach
	void tearDown() throws Exception {
		System.setSecurityManager(null);
		grade -= pointsLost;
	}
	
	@Test
	@DisplayName("ClosedHashing - Single Hash")
	public void closedSingle() throws HashTableKeyException {
		try {
			HashSimulator.main(null);
			String actual = out.toString().split(".*Hashing: FUNC.*")[1];
			ArrayList<Double> actualNums = getNumsFromSimulation(actual);;
			System.setOut(originalOut);
			int assertionsCount = 6;
			// ClosedHashing - Single hash
			double[] expectedC1 = {650, 0.33692307692307694, 1.254060324825986,
					1.637213946953343, 106.67076923076922, 118, 92.31692307692308, 0};
			assertAll("ClosedHashing - Single hash", 
					() -> assertInRange(actualNums, expectedC1[0], assertionsCount),
					() -> assertInRange(actualNums, expectedC1[1], assertionsCount),
					() -> assertInRange(actualNums, expectedC1[2], assertionsCount),
					() -> assertInRange(actualNums, expectedC1[3], assertionsCount),
					() -> assertInRange(actualNums, expectedC1[4], assertionsCount),
					() -> assertInRange(actualNums, expectedC1[6], assertionsCount));
		} catch(Exception | StackOverflowError | NoClassDefFoundError e) {
			pointsLost = POINTS_PER_TEST;
			fail(failMsg(UNEXPECTED_EXCEPTION, 1));
		}
	}
	
	@Test
	@DisplayName("ClosedHashing - Double Hash")
	public void closedDouble() throws HashTableKeyException {
		try {
			HashSimulator.main(null);
			String actual = out.toString().split(".*Hashing: FUNC.*")[2];
			ArrayList<Double> actualNums = getNumsFromSimulation(actual);;
			System.setOut(originalOut);
			int assertionsCount = 6;
			// ClosedHashing - Double hash
			double[] expected = {650, 0.3346153846153846, 1.2514450867052023,
					1.6293394366667777, 88.5323076923077, 121, 77.1923076923077, 0};
			assertAll("ClosedHashing - Single hash", 
					() -> assertInRange(actualNums, expected[0], assertionsCount),
					() -> assertInRange(actualNums, expected[1], assertionsCount),
					() -> assertInRange(actualNums, expected[2], assertionsCount),
					() -> assertInRange(actualNums, expected[3], assertionsCount),
					() -> assertInRange(actualNums, expected[4], assertionsCount),
					() -> assertInRange(actualNums, expected[6], assertionsCount));
		} catch(Exception | StackOverflowError | NoClassDefFoundError e) {
			pointsLost = POINTS_PER_TEST;
			fail(failMsg(UNEXPECTED_EXCEPTION, 1));
		}
	}
	
	@Test
	@DisplayName("OpenHashing - Single Hash")
	public void openSingle() throws HashTableKeyException {
		try {
			HashSimulator.main(null);
			String actual = out.toString().split(".*Hashing: FUNC.*")[3];
			ArrayList<Double> actualNums = getNumsFromSimulation(actual);;
			System.setOut(originalOut);
			int assertionsCount = 6;
			// OpenHashing - Single hash
			double[] expected = {650, 3.0597014925373136, 2.529850746268657,
					3.0597014925373136, 2.4676923076923076, 3, 0.6307692307692307, 1};
			assertAll("OpenHashing - Single hash", 
					() -> assertInRange(actualNums, expected[0], assertionsCount),
					() -> assertInRange(actualNums, expected[1], assertionsCount),
					() -> assertInRange(actualNums, expected[2], assertionsCount),
					() -> assertInRange(actualNums, expected[3], assertionsCount),
					() -> assertInRange(actualNums, expected[4], assertionsCount),
					() -> assertInRange(actualNums, expected[6], assertionsCount));
		} catch(Exception | StackOverflowError | NoClassDefFoundError e) {
			pointsLost = POINTS_PER_TEST;
			fail(failMsg(UNEXPECTED_EXCEPTION, 1));
		}
	}
			
	@Test
	@DisplayName("OpenHashing - Double Hash")
	public void openDouble() throws HashTableKeyException {
		try {
			HashSimulator.main(null);
			String actual = out.toString().split(".*Hashing: FUNC.*")[4];
			ArrayList<Double> actualNums = getNumsFromSimulation(actual);;
			System.setOut(originalOut);
			int assertionsCount = 6;
			// OpenHashing - Double hash
			double[] expected = {650, 5.857142857142857, 3.9285714285714284,
					5.857142857142857, 3.286153846153846, 4, 0.6307692307692307, 1};
			assertAll("OpenHashing - Double hash", 
					() -> assertInRange(actualNums, expected[0], assertionsCount),
					() -> assertInRange(actualNums, expected[1], assertionsCount),
					() -> assertInRange(actualNums, expected[2], assertionsCount),
					() -> assertInRange(actualNums, expected[3], assertionsCount),
					() -> assertInRange(actualNums, expected[4], assertionsCount),
					() -> assertInRange(actualNums, expected[6], assertionsCount));
		} catch(Exception | StackOverflowError | NoClassDefFoundError e) {
			pointsLost = POINTS_PER_TEST;
			fail(failMsg(UNEXPECTED_EXCEPTION, 1));
		}
	}
			
			
	
	private String failMsg(String msg, int numberOfAssertionsInTest, double expected, double actual) {
		return String.format(msg + " Expected %f; received %f. (-%.2f pts)", expected, actual, POINTS_PER_TEST/(double)numberOfAssertionsInTest);
	}
	
	private String failMsg(String msg, int numberOfAssertionsInTest) {
		return String.format(msg + " (-%.2f pts)", POINTS_PER_TEST/(double)numberOfAssertionsInTest);
	}
	
	private void assertInRange(ArrayList<Double> actuals, double expected, int assertionsCount) {
		String error = "Simulation did not print the expected value.";
		String error50 = "Simulation results slightly missed the mark.";
		
		double bestMatch = actuals.get(0);
		for(Double d : actuals) {
			if(accurate15(d, expected)) {
				assertTrue(true, failMsg(error, assertionsCount, expected, d));
				return;
			}
			else
				if(Math.abs(expected-d) < Math.abs(expected-bestMatch))
					bestMatch = d;
		}
		
		if(accurate30(bestMatch, expected)) {
			pointsLost += (POINTS_PER_TEST/assertionsCount)/2;
			fail(failMsg(error50, 2*assertionsCount, expected, bestMatch));
		} else {
			pointsLost += POINTS_PER_TEST/assertionsCount;
			fail(failMsg(error, assertionsCount, expected, bestMatch));
		}
	}
	
	private boolean accurate15(double actual, double expected) {
		if(actual >= expected * 0.85 && actual <= expected * 1.15)
			return true;
		return false;
	}
	
	private boolean accurate30(double actual, double expected) {
		if(actual >= expected * 0.70 && actual <= expected * 1.30)
			return true;
		return false;
	}
	
	private ArrayList<Double> getNumsFromSimulation(String simulationOutput) {
		Pattern p = Pattern.compile("\\b(\\d+(?:\\.\\d+)?)\\b");
		Matcher m = p.matcher(simulationOutput);
		ArrayList<Double> arr = new ArrayList<Double>();
		while(m.find())
			arr.add(Double.parseDouble(m.group()));
		
		return arr;
	}
	
	private double getNumFromLine(String line) {
		Pattern p = Pattern.compile("\\b(\\d+(?:\\.\\d+)?)\\b");
		Matcher m = p.matcher(line);
		m.find();
		
		return Double.parseDouble(m.group(0));
	}
		
	 private static class NoExitSecurityManager extends SecurityManager {
		
        @Override
        public void checkPermission(Permission perm) {
            // allow anything.
        }
        @Override
        public void checkPermission(Permission perm, Object context) {
            // allow anything.
        }
        @Override
        public void checkExit(int status) 
        {
            super.checkExit(status);
            throw new ExitException(status);
        }
	 }
	 
	 protected static class ExitException extends SecurityException {
		private static final long serialVersionUID = -8576748019682914998L;
		public final int status;
        public ExitException(int status) {
        	System.out.println("System.exit(" + String.valueOf(status) + ")");
	        this.status = status;
        }
    }
	
	 protected abstract class Assertion {
		 abstract void checkAssertion();
	 }
}
